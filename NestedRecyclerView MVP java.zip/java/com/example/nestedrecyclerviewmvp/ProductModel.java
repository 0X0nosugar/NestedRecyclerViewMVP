package com.example.nestedrecyclerviewmvp;

/**
 *
 * Created  on 26.03.2017.
 */
public class ProductModel
{
    private int mImageRes;

    public int getImageRes() {
        return mImageRes;
    }

    public void setImageRes(int mImageRes) {
        this.mImageRes = mImageRes;
    }
}
