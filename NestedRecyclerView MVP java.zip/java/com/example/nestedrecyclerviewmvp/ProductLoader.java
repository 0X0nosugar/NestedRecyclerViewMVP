package com.example.nestedrecyclerviewmvp;

import android.os.Handler;
import android.util.Log;

import com.example.nestedrecyclerviewmvp.mvp.InteractorLayer;
import com.example.nestedrecyclerviewmvp.mvp.InteractorListener;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created on 26.03.2017.
 */
public class ProductLoader implements InteractorLayer
{
    private InteractorListener mInteractorListener;

    public ProductLoader(InteractorListener interactorListener){
        mInteractorListener = interactorListener;
    }

    @Override
    public void getProducts(final int categoryId) {
        final List<ProductModel> products = new ArrayList<>();
        for (int i=0;i<3;i++) {
            ProductModel productModel = new ProductModel();
            productModel.setImageRes(R.drawable.cream);
            ProductModel productModel2 = new ProductModel();
            productModel2.setImageRes(R.drawable.eyeshadows);
            products.add(productModel);
            products.add(productModel2);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mInteractorListener.onProductsLoaded(categoryId, products);
            }
        },4000);
    }

    @Override
    public void getCategories() {
        final List<CategoryModel> categories = new ArrayList<>();
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setCategoryName("Products 1");

        CategoryModel categoryModel2 = new CategoryModel();
        categoryModel2.setCategoryName("Products 2");

        categories.add(categoryModel);
        categories.add(categoryModel2);

        mInteractorListener.onCategoriesLoaded(categories);
    }

}
