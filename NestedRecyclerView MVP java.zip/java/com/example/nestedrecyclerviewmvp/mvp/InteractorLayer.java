package com.example.nestedrecyclerviewmvp.mvp;

/**
 *
 * Created  on 26.03.2017.
 */
public interface InteractorLayer {
    void getProducts(int categoryId);

    void getCategories();
}

