package com.example.nestedrecyclerviewmvp.mvp;

import com.example.nestedrecyclerviewmvp.AllProductsAdapter;
import com.example.nestedrecyclerviewmvp.ProductsAdapter;

/**
 *
 * Created  on 26.03.2017.
 */
public interface PresenterLayer
{
    void onViewReady();

    void presentProductItem(ProductsAdapter.SimpleListItemView view, int position);

    void presentCategoryItem(AllProductsAdapter.CategoryView view, int position);

}
