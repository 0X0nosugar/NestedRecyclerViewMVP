package com.example.nestedrecyclerviewmvp.mvp;

import com.example.nestedrecyclerviewmvp.CategoryModel;

import java.util.List;

/**
 *
 * Created on 26.03.2017.
 */
public interface ViewLayer
{
    /**
     * The contract: categoryItemList will always point to the same List, which may only be modified by the Presenter
     * @param data x
     */
    void setAllData(List<CategoryModel> data);

    /**
     *  Refresh one item of the outer RecyclerView after the Presenter has updated the data for this item
     * @param categoryPosition position of the updated item in the list of categories
     */
    void showProductsInCategory(int categoryPosition);

    /**
     * refresh the (outer) RecyclerView after the Presenter has updated the list
     */
    void showCategories();
}
