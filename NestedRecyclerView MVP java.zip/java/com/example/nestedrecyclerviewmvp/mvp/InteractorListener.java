package com.example.nestedrecyclerviewmvp.mvp;

import com.example.nestedrecyclerviewmvp.CategoryModel;
import com.example.nestedrecyclerviewmvp.ProductModel;

import java.util.List;

/**
 *
 * Created  on 26.03.2017.
 */
public interface InteractorListener
{

        void onProductsLoaded(int id, List<ProductModel> products);

        void onCategoriesLoaded(List<CategoryModel> categories);

}
