package com.example.nestedrecyclerviewmvp;

import com.example.nestedrecyclerviewmvp.mvp.InteractorLayer;
import com.example.nestedrecyclerviewmvp.mvp.InteractorListener;
import com.example.nestedrecyclerviewmvp.mvp.PresenterLayer;
import com.example.nestedrecyclerviewmvp.mvp.ViewLayer;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created on 26.03.2017.
 */
public class Presenter implements PresenterLayer, InteractorListener
{
    private InteractorLayer mInteractorLayer;
    private ViewLayer mViewLayer;
    private List<CategoryModel> mCategoryList = new ArrayList<>();

    public Presenter(ViewLayer viewLayer){
        mViewLayer = viewLayer;
        mViewLayer.setAllData(mCategoryList);
        mInteractorLayer = new ProductLoader(this);
    }

    @Override
    public void onViewReady(){
        mInteractorLayer.getCategories();
    }

    @Override
    public void presentProductItem(ProductsAdapter.SimpleListItemView view, int position){

    }

    @Override
    public void presentCategoryItem(AllProductsAdapter.CategoryView view, int position) {

    }

    /**
     * If there is a product List for this category: clear it. If not, create one. Copy everything from 'products'
     * @param categoryPosition x
     * @param products x
     */
    @Override
    public void onProductsLoaded(int categoryPosition, List<ProductModel> products) {
        List<ProductModel> productList = mCategoryList.get(categoryPosition).getProductList();
        if (productList == null){
            productList = new ArrayList<>();
            mCategoryList.get(categoryPosition).setProductList(products);
        }
        else{
            productList.clear();
        }
        productList.addAll(products);
        mViewLayer.showProductsInCategory(categoryPosition);
    }

    @Override
    public void onCategoriesLoaded(List<CategoryModel> categories) {
        mCategoryList.clear();
        mCategoryList.addAll(categories);
        mViewLayer.showCategories();
        for (int i=0; i<categories.size(); i++)
            mInteractorLayer.getProducts(i);
    }
}
