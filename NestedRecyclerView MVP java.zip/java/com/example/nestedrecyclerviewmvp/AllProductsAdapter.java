package com.example.nestedrecyclerviewmvp;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.nestedrecyclerviewmvp.mvp.ViewLayer;

import java.util.List;


/**
 *
 * Created  on 26.03.2017.
 */
public class AllProductsAdapter extends RecyclerView.Adapter<AllProductsAdapter.ItemViewHolder> implements ViewLayer
{
    private List<CategoryModel> mCategories;
   // private PresenterLayer mPresenter;

    public AllProductsAdapter(){}

    public AllProductsAdapter(List<CategoryModel> categoryItemList) {
        mCategories = categoryItemList;
     //   mPresenter = presenter;
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        holder.setCategoryName(mCategories.get(position).getCategoryName());
        holder.setProductList(mCategories.get(position).getProductList());
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category,parent,false);
        return new ItemViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return mCategories != null ? mCategories.size() : 0;
    }

    @Override
    public void setAllData(List<CategoryModel> data)
    {
        if (data == null) return;

        if (mCategories == null)
        {
            mCategories = data;
        }
        else {
            mCategories.clear();
            mCategories.addAll(data);
        }
    }

    @Override
    public void showProductsInCategory(int categoryPosition)
    {
        if (mCategories == null || categoryPosition < 0 || categoryPosition >= mCategories.size() )
            return;
        notifyItemChanged(categoryPosition);
    }

    @Override
    public void showCategories()
    {
        notifyDataSetChanged();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder implements CategoryView{
        TextView categoryNameView;
        RecyclerView productsRecycler;

        public ItemViewHolder(View itemView) {
            super(itemView);
            categoryNameView = (TextView) itemView.findViewById(R.id.category_name);
            productsRecycler = (RecyclerView) itemView.findViewById(R.id.product_items);
            productsRecycler.setLayoutManager(new LinearLayoutManager(itemView.getContext(),LinearLayoutManager.HORIZONTAL,false));
            productsRecycler.setItemAnimator(new DefaultItemAnimator());
            productsRecycler.setAdapter(new ProductsAdapter(null));
        }

        @Override
        public void setCategoryName(String categoryName) {
            categoryNameView.setText(categoryName);
        }

        @Override
        public void setProductList(List<ProductModel> productList) {
            ProductsAdapter productsAdapter = (ProductsAdapter) productsRecycler.getAdapter();
            productsAdapter.setProductList(productList);
            productsAdapter.notifyDataSetChanged();
        }
    }

    public interface CategoryView{
        void setCategoryName(String categoryName);
        void setProductList(List<ProductModel> productList);
    }
}
